import logging
import PyPDF2
import azure.functions as func
import io
import requests
import time
import pickle
import json
from azure.cognitiveservices.language.textanalytics import TextAnalyticsClient
from msrest.authentication import CognitiveServicesCredentials
subscription_key= "d0e35f28da5041648030ab83120766cb"
endpoint = "https://snpwebtext.cognitiveservices.azure.com/"
def authenticateClient():
    credentials = CognitiveServicesCredentials(subscription_key)
    text_analytics_client = TextAnalyticsClient(
        endpoint=endpoint, credentials=credentials)
    return text_analytics_client

client = authenticateClient()
def hyp(PDF):
    pages = PDF.getNumPages()
    key = '/Annots'
    uri = '/URI'
    ank = '/A'
    li=[]
    for page in range(pages):
        pageSliced = PDF.getPage(page)
        pageObject = pageSliced.getObject()
        if key in pageObject.keys():
            ann = pageObject[key]
            for a in ann:
                u = a.getObject()
                if uri in u[ank].keys():
                    li.append([page,u[ank][uri]])
    return li
def Sentiment(img_text):
    senti=[]
    documents=[]
    k=0
    key_p=[]
    enti=[]
    total=[]
    for i in img_text:
        documents.append({"id": f"{k}", "text": f"{i}"})
        k+=1
    response = client.sentiment(documents=documents)
    for document in response.documents:
        senti.append([document.id,document.score])
    response = client.key_phrases(documents=documents)
    for document in response.documents:
        key_p.append([document.id,[phrase for phrase in document.key_phrases]])
    response = client.entities(documents=documents)
    for document in response.documents:
        enti.append([document.id,[entity.name for entity in document.entities if entity.sub_type != 'Number' ]])
    total.append([senti,key_p,enti])
    return total




def pdf_img(pdf):
    startmark = b'\xff\xd8'
    startfix = 0
    endmark = b'\xff\xd9'
    endfix = 2
    i = 0
    zp=[]
    njpg = 0
    while True:
        
        istream = pdf.find(b'stream', i)
        if istream < 0:
            break
        istart = pdf.find(startmark, istream, istream+20)
        if istart < 0:
            i = istream+20
            continue
        iend = pdf.find(b"endstream", istart)
        if iend < 0:
            raise Exception(b"Didn't find end of stream!")
        iend = pdf.find(endmark, iend-20)
        if iend < 0:
            raise Exception(b"Didn't find end of JPG!")
        
        istart += startfix
        iend += endfix
        jpg = pdf[istart:iend]
        zp.append([jpg,"f/jpg%d.jpg" % njpg])
        njpg += 1
        i = iend
    return zp

def text(read_pdf):
    a=[]
    for i in range(read_pdf.getNumPages()):
        page=read_pdf.getPage(i)
        con=page.extractText()
        a.append([i,con])
    return a
 
def img_text(image_data):
    # Add your Computer Vision subscription key and endpoint to your environment variables.
    subscription_key="7e3f79003dc44b78903a1a3493ebf932"
    endpoint="https://snpwebvision.cognitiveservices.azure.com/"
    #"vision/v2.1/read/core/asyncBatchAnalyze"
    #https://snpdoc.cognitiveservices.azure.com/vision/v2.0/recognizeText?mode=Handwritten
    text_recognition_url = endpoint + "vision/v2.0/recognizeText?mode=Handwritten"

    # Set image_url to the URL of an image that you want to analyze.
    headers = {'Ocp-Apim-Subscription-Key': subscription_key,
            'Content-Type': 'application/octet-stream'}
    response = requests.post(
        text_recognition_url, headers=headers, data=image_data)
    try:
        response.raise_for_status()
    except Exception as e: 
        logging.info(e)
        return ''

    # Extracting text requires two API calls: One call to submit the
    # image for processing, the other to retrieve the text found in the image.

    # Holds the URI used to retrieve the recognized text.

    # The recognized text isn't immediately available, so poll to wait for completion.
    analysis = {}
    poll = True
    while (poll):
        response_final = requests.get(
            response.headers["Operation-Location"], headers=headers)
        analysis = response_final.json()
        #print(analysis)
        time.sleep(1)
        if ("recognitionResult" in analysis):
            poll = False
        if ("status" in analysis and analysis['status'] == 'Failed'):
            poll = False

    polygons = []
    if ("recognitionResult" in analysis):
        # Extract the recognized text, with bounding boxes.
        polygons = [(line["text"])
                    for line in analysis["recognitionResult"]["lines"]]
    return ' '.join(polygons)

def tages(image_data):
    subscription_key = "7e3f79003dc44b78903a1a3493ebf932"
    endpoint = "https://snpwebvision.cognitiveservices.azure.com/"
    # Add your Computer Vision subscription key and endpoint to your environment variables.
    analyze_url = endpoint + "vision/v2.1/analyze"
    headers = {'Ocp-Apim-Subscription-Key': subscription_key,
               'Content-Type': 'application/octet-stream'}
    params = {'visualFeatures': 'Categories,Description,Color'}
    response = requests.post(
        analyze_url, headers=headers, params=params, data=image_data)
    response.raise_for_status()

    # The 'analysis' object contains various fields that describe the image. The most
    # relevant caption for the image is obtained from the 'description' property.
    analysis = response.json()
    return [analysis['description']["tags"][:6],analysis['categories']]




def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    filename = req.params.get('name')
    if not filename:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            time.sleep(10)
            filename = req_body.get('name')
    sen=[]
    tage=[]
    if filename:
        image_text=[]
        final=[]
        myblob=requests.get(f'https://snpweb.blob.core.windows.net/snpweb/{filename}').content
        with io.BytesIO(myblob) as open_pdf_file:
            read_pdf = PyPDF2.PdfFileReader(open_pdf_file)
            hyper_link=hyp(read_pdf)
            pdf_text=text(read_pdf)
        pdf_image=pdf_img(myblob)
   
        k=0
        for i,j in pdf_image:  
            if k==15:
                break          
            image_text.append([img_text(i),j])
            tage.append(tages(i))
            k+=1
            for i in pdf_text:
                sen.append(i[1])
                logging.info(f"{i[1]}")
        final.append([hyper_link,pdf_text,image_text,pdf_image,Sentiment(image_text),Sentiment(sen),tage])
        x1=pickle.dumps(final)
        return func.HttpResponse(x1)
    else:
        time.sleep(10)
        return func.HttpResponse(
             "Please pass a name on the query string or in the request body",
             status_code=400
        )
